from django.contrib import admin

from accounts.models import *

# Register your models here.
admin.site.register(Role)
admin.site.register(User)